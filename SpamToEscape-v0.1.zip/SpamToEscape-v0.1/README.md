# Spam to Escape — Prototype v0.1

## What it contains
- Automatically generated enclosed school test arena with desks and dividers
- A terminal with a ProximityPrompt: each activation adds 1% progress and attracts the principal for four seconds
- A server-controlled Principal Detention that patrols, uses line-of-sight to chase, and pathfinds toward noise
- Damage on close contact, respawn through normal Roblox behavior
- Exit turns green at 100% progress; reaching it counts an escape in a **session-only** leaderboard

## Important limitations
This is an early **untested in Roblox Studio** prototype, not the full game. It has no inventory, hiding, downed/revive system, persistent data, round reset, polished animation, or complete school map. It may require debugging in Studio. The terminal currently takes 100 prompt activations as a simple placeholder.

## Install (Windows or Mac required)
1. Download Roblox Studio from https://create.roblox.com/ and open a new **Baseplate** experience.
2. Open **View > Command Bar** (the menu location may vary by Studio version).
3. Open `INSTALL_IN_STUDIO.lua` in a text editor and copy its **entire contents**.
4. Paste into the Studio **Command Bar** while in **Edit mode**, then press Enter. Do **not** paste it into a normal Script; normal scripts cannot set other scripts' `Source`.
5. Confirm the Output window says the prototype was installed.
6. Press **Play**, walk to the teal terminal, and repeatedly activate the `Hack (+1%)` prompt. Avoid the principal and escape through the door when it turns green.
7. Save the place to your own Roblox account using Studio's save/publish options. Keep the experience private while testing.

## Phone setup
1. Sign up for GitHub at https://github.com/signup.
2. Verify your email and enable 2FA.
3. Create a **private** repository named `SpamToEscape`.
4. Upload `INSTALL_IN_STUDIO.lua` and `README.md` using the GitHub mobile browser (desktop-site mode may help), or wait until you have a computer.
5. You cannot run Roblox Studio natively on an iPhone. Roblox mobile can play a published test experience, but it cannot edit it in Studio.

## Troubleshooting
- **Nothing appears**: check that you used Studio's Command Bar in Edit mode and read the Output errors.
- **NPC doesn't move**: ensure Play mode is running; check server Output. The generated NPC and simple pathfinding may need tuning.
- **Prompt doesn't show**: stand within 10 studs of the teal terminal.
- **Door won't open**: terminal progress must reach 100%; door turns green. This prototype doesn't reset rounds automatically.
- **Mobile prompt feels slow**: expected in v0.1; we'll replace the placeholder with a dedicated mobile-friendly hacking UI.

## Next build priorities
1. Replace 100 prompt activations with a responsive hacking minigame.
2. Add robust boss AI states and noise occlusion.
3. Add hiding and sprint/stamina.
4. Add randomized fuses and item spawns.
5. Add proper round reset, multiplayer testing, and UI.
