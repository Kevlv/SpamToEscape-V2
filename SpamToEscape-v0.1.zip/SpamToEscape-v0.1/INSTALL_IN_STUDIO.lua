-- Spam to Escape v0.1 - paste entire file into Roblox Studio Command Bar (Edit mode)
-- Creates a small playable test arena, a terminal, and a server-controlled principal.
local Workspace = game:GetService('Workspace')
local ServerScriptService = game:GetService('ServerScriptService')
local StarterGui = game:GetService('StarterGui')
local old = Workspace:FindFirstChild('SpamToEscapePrototype')
if old then old:Destroy() end
local oldServer = ServerScriptService:FindFirstChild('SpamToEscapeServer')
if oldServer then oldServer:Destroy() end
local oldGui = StarterGui:FindFirstChild('SpamToEscapeHUD')
if oldGui then oldGui:Destroy() end
local world = Instance.new('Folder'); world.Name='SpamToEscapePrototype'; world.Parent=Workspace
local function block(name, size, pos, color, anchored, collide)
 local p=Instance.new('Part'); p.Name=name; p.Size=size; p.Position=pos; p.Anchored=anchored~=false; p.CanCollide=collide~=false; p.Color=color; p.Material=Enum.Material.Concrete; p.Parent=world; return p
end
block('Floor',Vector3.new(110,1,90),Vector3.new(0,-0.5,0),Color3.fromRGB(75,79,86))
block('NorthWall',Vector3.new(110,18,2),Vector3.new(0,9,-45),Color3.fromRGB(37,45,57))
block('SouthWall',Vector3.new(110,18,2),Vector3.new(0,9,45),Color3.fromRGB(37,45,57))
block('EastWall',Vector3.new(2,18,90),Vector3.new(55,9,0),Color3.fromRGB(37,45,57))
block('WestWall',Vector3.new(2,18,90),Vector3.new(-55,9,0),Color3.fromRGB(37,45,57))
-- Two interior partitions with wide gaps for a chase loop
block('DividerA',Vector3.new(2,13,24),Vector3.new(-12,6.5,-31),Color3.fromRGB(51,62,74))
block('DividerB',Vector3.new(2,13,24),Vector3.new(-12,6.5,31),Color3.fromRGB(51,62,74))
block('DividerC',Vector3.new(2,13,24),Vector3.new(18,6.5,-31),Color3.fromRGB(51,62,74))
block('DividerD',Vector3.new(2,13,24),Vector3.new(18,6.5,31),Color3.fromRGB(51,62,74))
for i=1,6 do
 local desk=block('Desk'..i,Vector3.new(6,3,3),Vector3.new(-39+(i%3)*11,1.5,-25+math.floor((i-1)/3)*20),Color3.fromRGB(91,70,51))
 desk.Material=Enum.Material.Wood
end
local spawn=Instance.new('SpawnLocation'); spawn.Name='StudentSpawn'; spawn.Size=Vector3.new(8,1,8); spawn.Position=Vector3.new(-43,0.5,34); spawn.Anchored=true; spawn.Neutral=true; spawn.Color=Color3.fromRGB(63,166,139); spawn.Parent=world
local terminal=block('Terminal',Vector3.new(5,5,3),Vector3.new(-40,2.5,-32),Color3.fromRGB(31,116,126))
terminal.Material=Enum.Material.Metal
local prompt=Instance.new('ProximityPrompt'); prompt.Name='HackPrompt'; prompt.ActionText='Hack (+1%)'; prompt.ObjectText='Exit Terminal'; prompt.HoldDuration=0; prompt.MaxActivationDistance=10; prompt.RequiresLineOfSight=false; prompt.Parent=terminal
local label=Instance.new('BillboardGui'); label.Name='ProgressBillboard'; label.Size=UDim2.fromOffset(210,55); label.StudsOffset=Vector3.new(0,4,0); label.AlwaysOnTop=true; label.Parent=terminal
local text=Instance.new('TextLabel'); text.Name='Progress'; text.Size=UDim2.fromScale(1,1); text.BackgroundColor3=Color3.fromRGB(18,25,35); text.BackgroundTransparency=.1; text.TextColor3=Color3.fromRGB(170,255,230); text.TextScaled=true; text.Text='TERMINAL: 0%'; text.Parent=label
local exit=block('EscapeDoor',Vector3.new(7,10,1),Vector3.new(43,5,-44),Color3.fromRGB(164,54,54)); exit.Material=Enum.Material.Neon
local exitPrompt=Instance.new('ProximityPrompt'); exitPrompt.Name='EscapePrompt'; exitPrompt.ActionText='Escape'; exitPrompt.ObjectText='LOCKED EXIT'; exitPrompt.MaxActivationDistance=9; exitPrompt.Parent=exit
local principal=Instance.new('Model'); principal.Name='PrincipalDetention'; principal.Parent=world
local root=Instance.new('Part'); root.Name='HumanoidRootPart'; root.Size=Vector3.new(3,5,3); root.Position=Vector3.new(34,4,25); root.Transparency=1; root.CanCollide=false; root.Anchored=false; root.Parent=principal
local torso=Instance.new('Part'); torso.Name='Torso'; torso.Size=Vector3.new(4,5,2); torso.Color=Color3.fromRGB(45,33,47); torso.Position=root.Position; torso.CanCollide=false; torso.Parent=principal
local weld=Instance.new('WeldConstraint'); weld.Part0=root; weld.Part1=torso; weld.Parent=root
local head=Instance.new('Part'); head.Name='Head'; head.Shape=Enum.PartType.Ball; head.Size=Vector3.new(3,3,3); head.Color=Color3.fromRGB(184,164,141); head.Position=root.Position+Vector3.new(0,4,0); head.CanCollide=false; head.Parent=principal
local weld2=Instance.new('WeldConstraint'); weld2.Part0=root; weld2.Part1=head; weld2.Parent=root
local eyes=Instance.new('PointLight'); eyes.Color=Color3.fromRGB(255,55,55); eyes.Range=12; eyes.Brightness=2; eyes.Parent=head
local humanoid=Instance.new('Humanoid'); humanoid.Name='Humanoid'; humanoid.WalkSpeed=11; humanoid.HipHeight=2.5; humanoid.MaxHealth=100000; humanoid.Health=100000; humanoid.Parent=principal
principal.PrimaryPart=root
local server=Instance.new('Script'); server.Name='SpamToEscapeServer'; server.Parent=ServerScriptService
server.Source=[==[
local Players=game:GetService('Players')
local PathfindingService=game:GetService('PathfindingService')
local RunService=game:GetService('RunService')
local world=workspace:WaitForChild('SpamToEscapePrototype')
local terminal=world:WaitForChild('Terminal')
local prompt=terminal:WaitForChild('HackPrompt')
local label=terminal.ProgressBillboard.Progress
local exit=world:WaitForChild('EscapeDoor')
local exitPrompt=exit.EscapePrompt
local npc=world:WaitForChild('PrincipalDetention')
local root=npc:WaitForChild('HumanoidRootPart')
local humanoid=npc:WaitForChild('Humanoid')
local progress=0
local noisePosition=nil
local noiseUntil=0
local won={}
local patrol={Vector3.new(34,3,25),Vector3.new(34,3,-25),Vector3.new(0,3,0),Vector3.new(-27,3,18)}
local patrolIndex=1
local lastHit={}
local function aliveCharacter(player)
 local char=player.Character
 local hum=char and char:FindFirstChildOfClass('Humanoid')
 local part=char and char:FindFirstChild('HumanoidRootPart')
 if hum and hum.Health>0 and part then return char,hum,part end
end
prompt.Triggered:Connect(function(player)
 local _,_,part=aliveCharacter(player)
 if not part or (part.Position-terminal.Position).Magnitude>12 or progress>=100 then return end
 progress=math.min(100,progress+1)
 label.Text='TERMINAL: '..progress..'%'
 noisePosition=part.Position
 noiseUntil=os.clock()+4
 if progress==100 then
  prompt.Enabled=false
  exit.Color=Color3.fromRGB(44,195,110)
  exitPrompt.ObjectText='EXIT OPEN'
  label.Text='EXIT UNLOCKED - RUN!'
 end
end)
exitPrompt.Triggered:Connect(function(player)
 if progress<100 or won[player] then return end
 local _,_,part=aliveCharacter(player)
 if not part or (part.Position-exit.Position).Magnitude>12 then return end
 won[player]=true
 local stats=player:FindFirstChild('leaderstats')
 if stats then stats.Escapes.Value+=1 end
 player:LoadCharacter()
end)
Players.PlayerAdded:Connect(function(player)
 local stats=Instance.new('Folder'); stats.Name='leaderstats'; stats.Parent=player
 local escapes=Instance.new('IntValue'); escapes.Name='Escapes'; escapes.Parent=stats
end)
Players.PlayerRemoving:Connect(function(player) won[player]=nil;lastHit[player]=nil end)
-- Simple server-authoritative chase AI. Recompute paths frequently, without blocking the main loop.
local function visibleTarget()
 local best,bestDist=nil,math.huge
 for _,player in ipairs(Players:GetPlayers()) do
  local char,_,part=aliveCharacter(player)
  if char then
   local delta=part.Position-root.Position
   if delta.Magnitude<48 and delta.Magnitude<bestDist then
    local params=RaycastParams.new(); params.FilterType=Enum.RaycastFilterType.Exclude; params.FilterDescendantsInstances={npc}
    local hit=workspace:Raycast(root.Position+Vector3.new(0,2,0),delta,params)
    if hit and hit.Instance:IsDescendantOf(char) then best=part;bestDist=delta.Magnitude end
   end
  end
 end
 return best
end
local currentDestination=nil
local nextWaypoint=nil
local waypointIndex=1
local waypoints={}
local lastPath=0
local function navigate(destination)
 if not destination then return end
 if os.clock()-lastPath>.9 or not currentDestination or (currentDestination-destination).Magnitude>7 then
  lastPath=os.clock();currentDestination=destination
  local path=PathfindingService:CreatePath({AgentRadius=2.5,AgentHeight=7,AgentCanJump=true,WaypointSpacing=5})
  local ok=pcall(function() path:ComputeAsync(root.Position,destination) end)
  if ok and path.Status==Enum.PathStatus.Success then waypoints=path:GetWaypoints(); waypointIndex=math.min(2,#waypoints)
  else waypoints={};waypointIndex=1 end
 end
 local wp=waypoints[waypointIndex]
 if wp then
  if (root.Position-wp.Position).Magnitude<4 then waypointIndex+=1;wp=waypoints[waypointIndex] end
  if wp then
   if wp.Action==Enum.PathWaypointAction.Jump then humanoid.Jump=true end
   humanoid:MoveTo(wp.Position)
  else humanoid:MoveTo(destination) end
 else humanoid:MoveTo(destination) end
end
local nextDamageCheck=0
while task.wait(.2) do
 local target=visibleTarget()
 local destination
 if target then
  destination=target.Position;humanoid.WalkSpeed=19
 elseif noisePosition and os.clock()<noiseUntil then
  destination=noisePosition;humanoid.WalkSpeed=14
 else
  noisePosition=nil;humanoid.WalkSpeed=10
  destination=patrol[patrolIndex]
  if (root.Position-destination).Magnitude<7 then patrolIndex=patrolIndex%#patrol+1;destination=patrol[patrolIndex] end
 end
 navigate(destination)
 if os.clock()>nextDamageCheck then
  nextDamageCheck=os.clock()+.2
  for _,player in ipairs(Players:GetPlayers()) do
   local _,hum,part=aliveCharacter(player)
   if hum and (part.Position-root.Position).Magnitude<5 and os.clock()-(lastHit[player] or 0)>2 then
    lastHit[player]=os.clock();hum:TakeDamage(35)
   end
  end
 end
end
]==]
local lighting=game:GetService('Lighting'); lighting.ClockTime=1; lighting.Brightness=1.5; lighting.Ambient=Color3.fromRGB(62,71,90)
print('Spam to Escape v0.1 installed! Press Play. Hack terminal 100 times, avoid Principal Detention, escape through green door.')
